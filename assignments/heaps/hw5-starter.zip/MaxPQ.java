package hw5;

import java.util.Arrays;
import java.util.NoSuchElementException;

// The book's MaxPQ (Algorithms 4e, §2.4): a binary heap stored in pq[1..n].
// pq[0] is not used. You'll write swim and sink. Everything else is done.
// Search for TODO to find the parts you'll complete
public class MaxPQ<Key extends Comparable<Key>> {

    private Key[] pq;   // heap-ordered complete binary tree in pq[1..n]
    private int n;      // number of keys in the priority queue

    public long compares = 0;   // counted by less(), for HeapCompare

    // Creates an empty priority queue. (Already done.)
    @SuppressWarnings("unchecked")
    public MaxPQ() {
        pq = (Key[]) new Comparable[2];
    }

    // Is the priority queue empty? (Already done.)
    public boolean isEmpty() {
        return n == 0;
    }

    // Number of keys in the priority queue. (Already done.)
    public int size() {
        return n;
    }

    // Returns the largest key. (Already done.)
    public Key max() {
        if (isEmpty()) throw new NoSuchElementException("Priority queue underflow");
        return pq[1];
    }

    // Adds a key: put it at the end, then swim it up. (Already done.)
    public void insert(Key v) {
        if (n == pq.length - 1) resize(2 * pq.length);   // full: double the array
        pq[++n] = v;
        swim(n);
    }

    // Removes and returns the largest key: move the last key to the root,
    // then sink it down. (Already done.)
    public Key delMax() {
        if (isEmpty()) throw new NoSuchElementException("Priority queue underflow");
        Key max = pq[1];
        exch(1, n--);
        sink(1);
        pq[n + 1] = null;                                // avoid loitering
        if (n > 0 && n == (pq.length - 1) / 4) resize(pq.length / 2);
        return max;
    }

    // While the key at k is bigger than its parent, exchange it with its
    // parent and move up a level. Stop at the root (k = 1).
    //
    //   parent of k is k/2
    //
    // Use less(i, j) for every comparison and exch(i, j) for every exchange.
    private void swim(int k) {
        // TODO
    }

    // While the key at k is smaller than its LARGER child, exchange it with
    // that child and move down a level. Stop when k has no children.
    //
    //   children of k are 2k and 2k+1
    //   k has a child when 2*k <= n
    //   k has a right child only when 2*k < n
    //
    // Use less(i, j) for every comparison and exch(i, j) for every exchange.
    private void sink(int k) {
        // TODO
    }

    // Is pq[i] < pq[j]? (Already done.)
    private boolean less(int i, int j) {
        compares++;
        return pq[i].compareTo(pq[j]) < 0;
    }

    // Exchanges pq[i] and pq[j]. (Already done.)
    private void exch(int i, int j) {
        Key t = pq[i];
        pq[i] = pq[j];
        pq[j] = t;
    }

    // Moves the keys to a new array of the given capacity. (Already done.)
    @SuppressWarnings("unchecked")
    private void resize(int capacity) {
        Key[] temp = (Key[]) new Comparable[capacity];
        for (int i = 1; i <= n; i++) temp[i] = pq[i];
        pq = temp;
    }

    // Is pq[1..n] in heap order (every parent >= its children)? (Already done.)
    public boolean isMaxHeap() {
        for (int k = 2; k <= n; k++) {
            if (pq[k / 2].compareTo(pq[k]) < 0) return false;
        }
        return true;
    }

    // Returns pq[1..n] as text, for checking and debugging. (Already done.)
    public String show() {
        return Arrays.toString(Arrays.copyOfRange(pq, 1, n + 1));
    }
}
