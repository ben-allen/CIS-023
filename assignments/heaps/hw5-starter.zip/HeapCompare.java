package hw5;

// The experiment for Part 4. (Already done. Don't change this file.)
//
// Counts compares for your binary MaxPQ and your 3-ary MaxPQ3 doing the
// same work:
//   - insert n keys in increasing order (so every new key swims to the root)
//   - then delMax n times
public class HeapCompare {

    public static void main(String[] args) {
        System.out.printf("%-10s %-14s %16s %16s%n", "n", "heap", "insert compares", "delMax compares");
        for (int n : new int[] { 10_000, 100_000 }) {
            MaxPQ<Integer> two = new MaxPQ<Integer>();
            MaxPQ3<Integer> three = new MaxPQ3<Integer>();
            String[] r2 = run(two, n);
            String[] r3 = run3(three, n);
            System.out.printf("%-10s %-14s %16s %16s%n", String.format("%,d", n), "binary", r2[0], r2[1]);
            System.out.printf("%-10s %-14s %16s %16s%n", "", "3-ary", r3[0], r3[1]);
        }
    }

    private static String[] run(MaxPQ<Integer> pq, int n) {
        try {
            for (int i = 0; i < n; i++) pq.insert(i);
            long ins = pq.compares;
            pq.compares = 0;
            for (int i = n - 1; i >= 0; i--) {
                if (pq.delMax() != i) return new String[] { "NOT WORKING", "NOT WORKING" };
            }
            return new String[] { String.format("%,d", ins), String.format("%,d", pq.compares) };
        } catch (RuntimeException e) {
            return new String[] { "NOT WORKING", "NOT WORKING" };
        }
    }

    private static String[] run3(MaxPQ3<Integer> pq, int n) {
        try {
            for (int i = 0; i < n; i++) pq.insert(i);
            long ins = pq.compares;
            pq.compares = 0;
            for (int i = n - 1; i >= 0; i--) {
                if (pq.delMax() != i) return new String[] { "NOT WORKING", "NOT WORKING" };
            }
            return new String[] { String.format("%,d", ins), String.format("%,d", pq.compares) };
        } catch (RuntimeException e) {
            return new String[] { "NOT WORKING", "NOT WORKING" };
        }
    }
}
