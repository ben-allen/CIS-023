package hw5;

import java.util.Arrays;
import java.util.NoSuchElementException;

// A max priority queue stored as a 3-ary heap: every node has up to THREE
// children instead of two. It's the same idea as MaxPQ, in pq[1..n], with
// pq[0] unused. Only the shape of the tree is different.
//
// The index arithmetic is done for you: parent, firstChild, lastChild, and
// hasChild. Use them instead of writing k/2, 2*k, and so on.
//
// You write swim, largestChild, and sink. Search for TODO to find the parts
// you'll complete
public class MaxPQ3<Key extends Comparable<Key>> {

    private Key[] pq;   // heap-ordered complete 3-ary tree in pq[1..n]
    private int n;      // number of keys in the priority queue

    public long compares = 0;   // counted by less(), for HeapCompare

    // Creates an empty priority queue. (Already done.)
    @SuppressWarnings("unchecked")
    public MaxPQ3() {
        pq = (Key[]) new Comparable[2];
    }

    public boolean isEmpty() { return n == 0; }   // (Already done.)
    public int size() { return n; }               // (Already done.)

    // Returns the largest key. (Already done.)
    public Key max() {
        if (isEmpty()) throw new NoSuchElementException("Priority queue underflow");
        return pq[1];
    }

    // Same as MaxPQ's insert. (Already done.)
    public void insert(Key v) {
        if (n == pq.length - 1) resize(2 * pq.length);
        pq[++n] = v;
        swim(n);
    }

    // Same as MaxPQ's delMax. (Already done.)
    public Key delMax() {
        if (isEmpty()) throw new NoSuchElementException("Priority queue underflow");
        Key max = pq[1];
        exch(1, n--);
        sink(1);
        pq[n + 1] = null;
        if (n > 0 && n == (pq.length - 1) / 4) resize(pq.length / 2);
        return max;
    }

    // ------------------------------------------------ the index arithmetic
    //
    //                        1
    //            /           |           \
    //          2             3             4
    //        / | \         / | \         / | \
    //       5  6  7       8  9  10     11 12  13
    //
    // (Already done. HW5Client prints a few of these so you can check them
    // against the picture.)

    // The parent of node k. Only makes sense for k > 1.
    int parent(int k) {
        return (k + 1) / 3;
    }

    // The first (leftmost) child of node k.
    int firstChild(int k) {
        return 3 * k - 1;
    }

    // The last child of node k that's actually in the heap. A node near the
    // bottom can have only one or two children, so this stops at n.
    int lastChild(int k) {
        return Math.min(3 * k + 1, n);
    }

    // Does node k have at least one child?
    boolean hasChild(int k) {
        return firstChild(k) <= n;
    }

    // ------------------------------------------------ your code

    // While the key at k is bigger than its parent, exchange it with its
    // parent and move up. Stop at the root (k = 1).
    //
    // Hint: this is your MaxPQ swim, with one change.
    private void swim(int k) {
        // TODO
    }

    // Returns the index of the largest of k's children.
    // Only called when k has at least one child.
    //
    // Start with best = firstChild(k). Then look at each later child, up to
    // and including lastChild(k), and if pq[best] is less than it, make it
    // the new best. Use less() for every comparison.
    int largestChild(int k) {
        return 0; // TODO
    }

    // While k has a child, and the key at k is smaller than its largest
    // child, exchange them and move down.
    //
    // Hint: this is your MaxPQ sink, with the "pick the larger child" lines
    // replaced by a call to largestChild.
    private void sink(int k) {
        // TODO
    }

    // ------------------------------------------------ helpers (already done)

    private boolean less(int i, int j) {
        compares++;
        return pq[i].compareTo(pq[j]) < 0;
    }

    private void exch(int i, int j) {
        Key t = pq[i];
        pq[i] = pq[j];
        pq[j] = t;
    }

    @SuppressWarnings("unchecked")
    private void resize(int capacity) {
        Key[] temp = (Key[]) new Comparable[capacity];
        for (int i = 1; i <= n; i++) temp[i] = pq[i];
        pq = temp;
    }

    // Is pq[1..n] in heap order (every parent >= its children)?
    public boolean isMaxHeap() {
        for (int k = 2; k <= n; k++) {
            if (pq[parent(k)].compareTo(pq[k]) < 0) return false;
        }
        return true;
    }

    // Returns pq[1..n] as text, for checking and debugging.
    public String show() {
        return Arrays.toString(Arrays.copyOfRange(pq, 1, n + 1));
    }

    // Used by HW5Client to test largestChild on a fixed array, without
    // calling your swim. Don't use it in your own code.
    @SuppressWarnings("unchecked")
    void loadForTesting(Key[] keys) {
        pq = (Key[]) new Comparable[keys.length + 1];
        for (int i = 0; i < keys.length; i++) pq[i + 1] = keys[i];
        n = keys.length;
    }
}
