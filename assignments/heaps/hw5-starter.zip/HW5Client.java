package hw5;

import java.util.Arrays;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.function.Supplier;

// Tests your MaxPQ, MaxPQ3, and Heap. (Already done. Don't change this file.)
//
// Parts you haven't written yet will FAIL. That's expected: work through
// the parts in order, and get each one passing before you start the next.
public class HW5Client {

    public static void main(String[] args) {
        int passed = 0;

        System.out.println("Part 1: MaxPQ (swim and sink)");
        passed += part1();

        System.out.println();
        System.out.println("Part 2: MaxPQ3 (a 3-ary heap)");
        passed += part2();

        System.out.println();
        System.out.println("Part 3: Heap (buildHeap and sort)");
        passed += part3();

        System.out.println();
        System.out.println(passed + " of 13 tests passed");
    }

    // ---------------------------------------------------------------- Part 1
    private static int part1() {
        int ok = 0;
        MaxPQ<String> pq = new MaxPQ<String>();
        String t1 = attempt(() -> {
            for (String s : "T P R N H O A E I G".split(" ")) pq.insert(s);
            pq.insert("S");
            return pq.show();
        });
        ok += report(1, "insert S into T P R N H O A E I G", t1, "[T, S, R, N, P, O, A, E, I, G, H]");
        String t2 = attempt(() -> "returns " + pq.delMax() + " " + pq.delMax() + ", " + pq.show());
        ok += report(2, "then delMax() twice", t2, "returns T S, [R, P, O, N, H, G, A, E, I]");
        ok += report(3, "P Q E - X A M - P L E - (- means delMax)",
                attempt(() -> sequence(new MaxPQ<String>())), "returns Q X P, [P, M, L, A, E, E]");
        ok += randomTest(4, new MaxPQ<Integer>());
        return ok;
    }

    private static String sequence(MaxPQ<String> q) {
        StringBuilder got = new StringBuilder();
        for (String op : "P Q E - X A M - P L E -".split(" ")) {
            if (op.equals("-")) got.append(q.delMax()).append(' ');
            else q.insert(op);
        }
        return "returns " + got.toString().trim() + ", " + q.show();
    }

    private static int randomTest(int number, MaxPQ<Integer> mine) {
        Random random = new Random(5);
        PriorityQueue<Integer> ref = new PriorityQueue<Integer>(Collections.reverseOrder());
        String problem = null;
        try {
            for (int t = 0; t < 20_000 && problem == null; t++) {
                if (ref.isEmpty() || random.nextInt(3) > 0) {
                    int x = random.nextInt(1000);
                    mine.insert(x); ref.add(x);
                } else {
                    int a = mine.delMax(), b = ref.poll();
                    if (a != b) problem = "delMax() returned " + a + ", but the largest key was " + b;
                }
                if (problem == null && !mine.isMaxHeap()) problem = "heap order broken after operation " + (t + 1);
            }
        } catch (RuntimeException e) {
            problem = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        }
        return reportRandom(number, problem);
    }

    // ---------------------------------------------------------------- Part 2
    private static int part2() {
        int ok = 0;
        MaxPQ3<String> shape = new MaxPQ3<String>();
        shape.loadForTesting("A B C D E F G H I J K L M".split(" "));
        System.out.println("  (Index arithmetic, given: compare with the picture in MaxPQ3.java)");
        for (int k = 1; k <= 4; k++) {
            System.out.printf("    children of %d: %d to %d%n", k, shape.firstChild(k), shape.lastChild(k));
        }
        StringBuilder parents = new StringBuilder();
        for (int k = 2; k <= 13; k++) parents.append(' ').append(shape.parent(k));
        System.out.println("    parents of 2 to 13:" + parents);

        MaxPQ3<String> lc = new MaxPQ3<String>();
        lc.loadForTesting("Z B D C A F E H G J I".split(" "));
        String t5 = attempt(() -> lc.largestChild(1) + " " + lc.largestChild(2) + " " + lc.largestChild(3) + " " + lc.largestChild(4));
        ok += report(5, "largestChild of 1, 2, 3, 4 in Z B D C A F E H G J I", t5, "3 6 10 11");

        MaxPQ3<String> pq = new MaxPQ3<String>();
        String t6 = attempt(() -> {
            for (String s : "T P R N H O A E I G".split(" ")) pq.insert(s);
            pq.insert("S");
            return pq.show();
        });
        ok += report(6, "insert S into T P R N H O A E I G", t6, "[T, P, R, S, H, O, A, E, I, G, N]");
        String t7 = attempt(() -> "returns " + pq.delMax() + " " + pq.delMax() + ", " + pq.show());
        ok += report(7, "then delMax() twice", t7, "returns T S, [R, P, I, N, H, O, A, E, G]");
        ok += report(8, "P Q E - X A M - P L E - (- means delMax)", attempt(() -> {
            MaxPQ3<String> q = new MaxPQ3<String>();
            StringBuilder got = new StringBuilder();
            for (String op : "P Q E - X A M - P L E -".split(" ")) {
                if (op.equals("-")) got.append(q.delMax()).append(' ');
                else q.insert(op);
            }
            return "returns " + got.toString().trim() + ", " + q.show();
        }), "returns Q X P, [P, M, E, A, E, L]");

        Random random = new Random(5);
        MaxPQ3<Integer> mine = new MaxPQ3<Integer>();
        PriorityQueue<Integer> ref = new PriorityQueue<Integer>(Collections.reverseOrder());
        String problem = null;
        try {
            for (int t = 0; t < 20_000 && problem == null; t++) {
                if (ref.isEmpty() || random.nextInt(3) > 0) {
                    int x = random.nextInt(1000);
                    mine.insert(x); ref.add(x);
                } else {
                    int a = mine.delMax(), b = ref.poll();
                    if (a != b) problem = "delMax() returned " + a + ", but the largest key was " + b;
                }
                if (problem == null && !mine.isMaxHeap()) problem = "heap order broken after operation " + (t + 1);
            }
        } catch (RuntimeException e) {
            problem = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        }
        ok += reportRandom(9, problem);
        return ok;
    }

    // ---------------------------------------------------------------- Part 3
    private static int part3() {
        int ok = 0;
        ok += report(10, "buildHeap(S O R T E X A M P L E)", attempt(() -> {
            String[] a = "S O R T E X A M P L E".split(" ");
            Heap.buildHeap(a);
            return Arrays.toString(a);
        }), "[X, T, S, P, L, R, A, M, O, E, E]");
        ok += report(11, "sort(S O R T E X A M P L E)", attempt(() -> {
            String[] b = "S O R T E X A M P L E".split(" ");
            Heap.sort(b);
            return Arrays.toString(b);
        }), "[A, E, E, L, M, O, P, R, S, T, X]");

        Random random = new Random(555);
        Double[] c = new Double[10_000];
        for (int i = 0; i < c.length; i++) c[i] = random.nextDouble();
        ok += report(12, "sort 10,000 random numbers", verdict(c), "OK");
        Integer[] d = new Integer[10_000];
        for (int i = 0; i < d.length; i++) d[i] = random.nextInt(3);
        ok += report(13, "sort 10,000 random 0s, 1s, and 2s", verdict(d), "OK");
        return ok;
    }

    private static String verdict(Comparable[] a) {
        Comparable[] expected = a.clone();
        Arrays.sort(expected);
        try {
            Heap.sort(a);
        } catch (RuntimeException e) {
            return e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        }
        for (int i = 1; i < a.length; i++) if (a[i].compareTo(a[i - 1]) < 0) return "NOT SORTED";
        if (!Arrays.equals(expected, a)) return "SORTED, BUT ITEMS WERE LOST OR DUPLICATED";
        return "OK";
    }

    // ---------------------------------------------------------------- helpers
    // Runs a test, turning a crash into a readable result instead of stopping.
    private static String attempt(Supplier<String> test) {
        try {
            return test.get();
        } catch (RuntimeException e) {
            return e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        }
    }

    private static int report(int number, String what, String result, String expect) {
        boolean pass = result.equals(expect);
        System.out.printf("  Test %d: %s  %s%n", number, what, pass ? "PASS" : "FAIL");
        if (!pass) {
            System.out.println("    result: " + result);
            System.out.println("    expect: " + expect);
        }
        return pass ? 1 : 0;
    }

    private static int reportRandom(int number, String problem) {
        System.out.printf("  Test %d: 20,000 random inserts and delMax calls  %s%n", number, problem == null ? "PASS" : "FAIL");
        if (problem != null) System.out.println("    " + problem);
        return problem == null ? 1 : 0;
    }
}
