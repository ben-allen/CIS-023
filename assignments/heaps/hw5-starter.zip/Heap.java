package hw5;

import java.util.Arrays;

// Heapsort (Algorithms 4e, §2.4). The heap logic counts from 1, like MaxPQ:
// heap index k is stored in Java's a[k-1]. less() and exch() do that
// translation for you, so in buildHeap, sort, and sink you can think in
// heap indices 1..n and never write "- 1" yourself.
//
// You write buildHeap, sort, and sink.
public class Heap {

    // Phase 1: rearranges a[] into a max-heap.
    // For k from n/2 down to 1, call sink(a, k, n), where n = a.length.
    //
    // (The book's Heap.sort writes this loop inside sort. It's split out
    // here so HeapClient can check phase 1 on its own.)
    public static void buildHeap(Comparable[] a) {
        // TODO
    }

    // Sorts a[] into ascending order.
    //   1. Call buildHeap(a).
    //   2. Phase 2 (sortdown): let k = n. While k > 1:
    //        - exch(a, 1, k): the largest key goes to its final position
    //        - k-- : the heap is now one smaller
    //        - sink(a, 1, k): fix the heap a[1..k]
    public static void sort(Comparable[] a) {
        // TODO
    }

    // Sinks the key at heap index k in a heap of size n (heap indices 1..n).
    // Same as MaxPQ's sink, but the array and the heap size are passed in,
    // because the heap shrinks during phase 2.
    private static void sink(Comparable[] a, int k, int n) {
        // TODO
    }

    // Is heap index i less than heap index j? (Already done.)
    private static boolean less(Comparable[] a, int i, int j) {
        return a[i - 1].compareTo(a[j - 1]) < 0;
    }

    // Exchanges heap indices i and j. (Already done.)
    private static void exch(Object[] a, int i, int j) {
        Object swap = a[i - 1];
        a[i - 1] = a[j - 1];
        a[j - 1] = swap;
    }

    // Prints the array on one line, for debugging. (Already done.)
    public static void show(Comparable[] a) {
        System.out.println(Arrays.toString(a));
    }
}
