package hw6;

import java.util.ArrayDeque;
import java.util.Queue;

// The book's binary search tree (Algorithms 4e, §3.2), with a size count in
// every node, as in the slides. get, put, min, max, deleteMin, and delete
// are done. You write the methods marked TODO.
public class BST<Key extends Comparable<Key>, Value> {

    private Node root;   // the root of the tree

    private class Node {
        private Key key;
        private Value val;
        private Node left, right;   // subtrees
        private int size;           // nodes in this subtree

        public Node(Key key, Value val, int size) {
            this.key = key;
            this.val = val;
            this.size = size;
        }
    }

    // ================================================================ given

    public boolean isEmpty() { return size() == 0; }

    // Number of keys in the table.
    public int size() { return size(root); }

    // Number of nodes in the subtree rooted at x. size(null) is 0.
    private int size(Node x) {
        if (x == null) return 0;
        return x.size;
    }

    public boolean contains(Key key) { return get(key) != null; }

    // The value paired with key, or null.
    public Value get(Key key) {
        Node x = root;
        while (x != null) {
            int cmp = key.compareTo(x.key);
            if      (cmp < 0) x = x.left;
            else if (cmp > 0) x = x.right;
            else return x.val;
        }
        return null;
    }

    public void put(Key key, Value val) {
        root = put(root, key, val);
    }

    private Node put(Node x, Key key, Value val) {
        if (x == null) return new Node(key, val, 1);
        int cmp = key.compareTo(x.key);
        if      (cmp < 0) x.left  = put(x.left,  key, val);
        else if (cmp > 0) x.right = put(x.right, key, val);
        else              x.val   = val;
        x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    public Key min() { return min(root).key; }

    private Node min(Node x) {
        if (x.left == null) return x;
        return min(x.left);
    }

    public Key max() { return max(root).key; }

    private Node max(Node x) {
        if (x.right == null) return x;
        return max(x.right);
    }

    // Removes the smallest key.
    public void deleteMin() {
        if (isEmpty()) return;
        root = deleteMin(root);
    }

    private Node deleteMin(Node x) {
        if (x.left == null) return x.right;
        x.left = deleteMin(x.left);
        x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    // Hibbard deletion, from the slides: a node with two children is
    // replaced by its SUCCESSOR, the smallest key in its right subtree.
    public void delete(Key key) {
        root = delete(root, key);
    }

    private Node delete(Node x, Key key) {
        if (x == null) return null;
        int cmp = key.compareTo(x.key);
        if      (cmp < 0) x.left  = delete(x.left,  key);
        else if (cmp > 0) x.right = delete(x.right, key);
        else {
            if (x.right == null) return x.left;
            if (x.left  == null) return x.right;
            Node t = x;
            x = min(t.right);                 // successor
            x.right = deleteMin(t.right);     // take it out
            x.left = t.left;                  // move it in
        }
        x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    // All the keys, in sorted order (an in-order traversal).
    public Iterable<Key> keys() {
        Queue<Key> q = new ArrayDeque<Key>();
        inorder(root, q);
        return q;
    }

    private void inorder(Node x, Queue<Key> q) {
        if (x == null) return;
        inorder(x.left, q);
        q.add(x.key);
        inorder(x.right, q);
    }

    // ================================================ Part 1 (warm-up)

    // How many keys in the table are smaller than key? Works whether or not
    // key is in the table.
    public int rank(Key key) {
        return rank(key, root);
    }

    private int rank(Key key, Node x) {
        return 0; // TODO
    }

    // The key with rank k: the key that has exactly k smaller keys.
    // k goes from 0 to size() - 1.
    public Key select(int k) {
        Node x = select(root, k);
        if (x == null) return null;
        return x.key;
    }

    private Node select(Node x, int k) {
        return null; // TODO
    }

    // ========================================================= Part 2

    // The number of nodes on the longest path from the root down to a leaf.
    // That's the largest number of compares a search hit can take.
    // An empty tree has height 0, and a tree with one node has height 1.
    public int height() {
        return height(root);
    }

    private int height(Node x) {
        return 0; // TODO
    }

    // Is the tree in symmetric order? Every key in a node's LEFT subtree must
    // be smaller than the node's key, and every key in its RIGHT subtree must
    // be bigger. Not just its children: everything below it.
    public boolean isBST() {
        return isBST(root, null, null);
    }

    // Is the subtree rooted at x in symmetric order, with every key in it
    // strictly between lo and hi? A null lo or hi means "no limit on that
    // side".
    private boolean isBST(Node x, Key lo, Key hi) {
        return false; // TODO
    }

    // ========================================================= Part 3

    // Removes the largest key. The mirror image of deleteMin.
    public void deleteMax() {
        if (isEmpty()) return;
        root = deleteMax(root);
    }

    private Node deleteMax(Node x) {
        return x; // TODO
    }

    // Hibbard deletion, mirrored: a node with two children is replaced by its
    // PREDECESSOR, the largest key in its left subtree. Otherwise exactly
    // like delete above.
    public void deletePredecessor(Key key) {
        root = deletePredecessor(root, key);
    }

    private Node deletePredecessor(Node x, Key key) {
        return x; // TODO
    }

    // ===================================================== debugging help

    // The tree as text: (left key:size right), with . for an empty subtree.
    // HW6Client uses this to check the shape of your tree.
    public String shape() {
        return shape(root);
    }

    private String shape(Node x) {
        if (x == null) return ".";
        if (x.left == null && x.right == null) return x.key + ":" + x.size;
        return "(" + shape(x.left) + " " + x.key + ":" + x.size + " " + shape(x.right) + ")";
    }

    // Prints the tree sideways (the root on the left, bigger keys on top),
    // with each node's size. Handy for checking your work.
    public void draw() {
        if (root == null) System.out.println("(empty)");
        draw(root, "");
    }

    private void draw(Node x, String indent) {
        if (x == null) return;
        draw(x.right, indent + "        ");
        System.out.println(indent + x.key + " (" + x.size + ")");
        draw(x.left, indent + "        ");
    }

    // Are all the size counts right? Used by HW6Client.
    boolean isSizeConsistent() { return isSizeConsistent(root); }

    private boolean isSizeConsistent(Node x) {
        if (x == null) return true;
        if (x.size != 1 + size(x.left) + size(x.right)) return false;
        return isSizeConsistent(x.left) && isSizeConsistent(x.right);
    }

    // Changes a key in place WITHOUT moving its node: exactly what the
    // "Keys must not change" slide warns about. HW6Client uses it to build
    // broken trees for testing isBST. Don't use it in your own code.
    void rekeyForTesting(Key oldKey, Key newKey) {
        Node x = root;
        while (x != null) {
            int cmp = oldKey.compareTo(x.key);
            if      (cmp < 0) x = x.left;
            else if (cmp > 0) x = x.right;
            else { x.key = newKey; return; }
        }
    }
}
