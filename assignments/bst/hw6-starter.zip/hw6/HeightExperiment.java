package hw6;

import java.util.Random;

// The experiment for Part 4. (Already done. Don't change this file.)
//
// Puts the same n keys into a BST in four different orders, and prints the
// height of each tree (using your height()).
public class HeightExperiment {

    // Sorted insertion makes a very tall tree, and put is recursive, so this
    // runs in a thread with a bigger stack than Java's default.
    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(null, HeightExperiment::experiment, "experiment", 512L * 1024 * 1024);
        t.start();
        t.join();
    }

    private static void experiment() {
        System.out.printf("%-10s %10s %10s %10s %10s   %s%n", "n", "sorted", "reversed", "shuffled", "balanced", "lg(n+1)");
        for (int n : new int[] { 1_023, 32_767 }) {
            Integer[] keys = new Integer[n];
            for (int i = 0; i < n; i++) keys[i] = i;

            int sorted = build(keys);

            Integer[] reversed = new Integer[n];
            for (int i = 0; i < n; i++) reversed[i] = n - 1 - i;
            int rev = build(reversed);

            Integer[] shuffled = keys.clone();
            Random random = new Random(2026);
            for (int i = 0; i < n; i++) {
                int r = i + random.nextInt(n - i);
                Integer tmp = shuffled[i]; shuffled[i] = shuffled[r]; shuffled[r] = tmp;
            }
            int shuf = build(shuffled);

            Integer[] balanced = new Integer[n];
            int[] next = { 0 };
            balancedOrder(keys, 0, n - 1, balanced, next);
            int bal = build(balanced);

            System.out.printf("%-10s %10d %10d %10d %10d   %.0f%n", String.format("%,d", n), sorted, rev, shuf, bal,
                    Math.log(n + 1) / Math.log(2));
        }
    }

    // Puts the keys in the given order into an empty BST; returns its height.
    private static int build(Integer[] order) {
        BST<Integer, Integer> st = new BST<Integer, Integer>();
        for (Integer k : order) st.put(k, 0);
        return st.height();
    }

    // Writes the sorted keys a[lo..hi] into out[] in an order that builds a
    // perfectly balanced BST: the middle key first, then (recursively) the
    // left half, then the right half.
    private static void balancedOrder(Integer[] a, int lo, int hi, Integer[] out, int[] next) {
        if (hi < lo) return;
        int mid = lo + (hi - lo) / 2;
        out[next[0]++] = a[mid];
        balancedOrder(a, lo, mid - 1, out, next);
        balancedOrder(a, mid + 1, hi, out, next);
    }
}
