package hw6;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.TreeMap;
import java.util.function.Supplier;

// Tests your BST methods. (Already done. Don't change this file.)
//
// Parts you haven't written yet will FAIL. That's expected: work through
// the parts in order, and get each one passing before you start the next.
//
// Most tests start from the tree in the slides: put S E A R C H E X A M P L E,
// each letter with its position.
//
//                 S
//              /     \
//            E         X
//          /   \
//         A     R
//          \   /
//           C H
//              \
//               M
//              / \
//             L   P
public class HW6Client {

    static BST<String, Integer> slideTree() {
        BST<String, Integer> st = new BST<String, Integer>();
        String[] keys = "S E A R C H E X A M P L E".split(" ");
        for (int i = 0; i < keys.length; i++) st.put(keys[i], i);
        return st;
    }

    // The slide tree, written the way shape() writes it.
    static final String SLIDE_SHAPE = "(((. A:2 C:1) E:8 ((. H:4 (L:1 M:3 P:1)) R:5 .)) S:10 X:1)";

    public static void main(String[] args) {
        int passed = 0;

        System.out.println("Part 1 (warm-up): rank and select");
        passed += report(1, "rank(N), rank(G), rank(A), rank(Z)",
                attempt(() -> { BST<String, Integer> t = slideTree();
                    return t.rank("N") + " " + t.rank("G") + " " + t.rank("A") + " " + t.rank("Z"); }),
                "6 3 0 10");
        passed += report(2, "select(5), select(0), select(9), select(3)",
                attempt(() -> { BST<String, Integer> t = slideTree();
                    return t.select(5) + " " + t.select(0) + " " + t.select(9) + " " + t.select(3); }),
                "M A X H");

        System.out.println();
        System.out.println("Part 2: height and isBST");
        passed += report(3, "height of: empty tree, one key, the slide tree, A..J in order",
                attempt(() -> {
                    BST<String, Integer> one = new BST<String, Integer>();
                    one.put("K", 0);
                    BST<String, Integer> sorted = new BST<String, Integer>();
                    for (String s : "A B C D E F G H I J".split(" ")) sorted.put(s, 0);
                    return new BST<String, Integer>().height() + " " + one.height() + " "
                            + slideTree().height() + " " + sorted.height();
                }), "0 1 6 10");
        passed += report(4, "isBST() on the slide tree, and on an empty tree",
                attempt(() -> slideTree().isBST() + " " + new BST<String, Integer>().isBST()), "true true");
        passed += report(5, "isBST() before and after the slides' change: H becomes Z",
                attempt(() -> { BST<String, Integer> t = slideTree(); boolean before = t.isBST();
                    t.rekeyForTesting("H", "Z"); return before + " " + t.isBST(); }),
                "true false");
        passed += report(6, "isBST() before and after C becomes F (bigger than its parent A, but also bigger than E)",
                attempt(() -> { BST<String, Integer> t = slideTree(); boolean before = t.isBST();
                    t.rekeyForTesting("C", "F"); return before + " " + t.isBST(); }),
                "true false");

        System.out.println();
        System.out.println("Part 3: deleteMax and deletePredecessor");
        passed += report(7, "deleteMax() twice",
                attempt(() -> { BST<String, Integer> t = slideTree(); t.deleteMax(); t.deleteMax(); return t.shape(); }),
                "((. A:2 C:1) E:8 ((. H:4 (L:1 M:3 P:1)) R:5 .))");
        passed += report(8, "deletePredecessor(L): a leaf",
                attempt(() -> { BST<String, Integer> t = slideTree(); t.deletePredecessor("L"); return t.shape(); }),
                "(((. A:2 C:1) E:7 ((. H:3 (. M:2 P:1)) R:4 .)) S:9 X:1)");
        passed += report(9, "deletePredecessor(A): one child",
                attempt(() -> { BST<String, Integer> t = slideTree(); t.deletePredecessor("A"); return t.shape(); }),
                "((C:1 E:7 ((. H:4 (L:1 M:3 P:1)) R:5 .)) S:9 X:1)");
        passed += report(10, "deletePredecessor(E): two children (the slides' \"Your turn\")",
                attempt(() -> { BST<String, Integer> t = slideTree(); t.deletePredecessor("E"); return t.shape(); }),
                "((A:1 C:7 ((. H:4 (L:1 M:3 P:1)) R:5 .)) S:9 X:1)");
        passed += report(11, "deletePredecessor(S): the root",
                attempt(() -> { BST<String, Integer> t = slideTree(); t.deletePredecessor("S"); return t.shape(); }),
                "(((. A:2 C:1) E:7 (. H:4 (L:1 M:3 P:1))) R:9 X:1)");
        passed += report(12, "deletePredecessor(G): not in the tree; then deletePredecessor(H): only a right child",
                attempt(() -> { BST<String, Integer> t = slideTree(); t.deletePredecessor("G");
                    String after = t.shape().equals(SLIDE_SHAPE) ? "unchanged" : "CHANGED: " + t.shape();
                    t.deletePredecessor("H"); return after + ", then " + t.shape(); }),
                "unchanged, then (((. A:2 C:1) E:7 ((L:1 M:3 P:1) R:4 .)) S:9 X:1)");
        passed += stress(13);

        System.out.println();
        System.out.println(passed + " of 13 tests passed");
    }

    // 20,000 random puts, deleteMax calls, and deletePredecessor calls, checked
    // against Java's own TreeMap after every operation.
    private static int stress(int number) {
        Random random = new Random(6);
        BST<Integer, Integer> mine = new BST<Integer, Integer>();
        TreeMap<Integer, Integer> ref = new TreeMap<Integer, Integer>();
        String problem = null;
        try {
            for (int t = 1; t <= 20_000 && problem == null; t++) {
                int op = random.nextInt(10);
                String what;
                if (op < 5) {
                    int k = random.nextInt(500), v = random.nextInt(1000);
                    mine.put(k, v); ref.put(k, v); what = "put(" + k + ")";
                } else if (op < 6) {
                    mine.deleteMax(); if (!ref.isEmpty()) ref.pollLastEntry(); what = "deleteMax()";
                } else {
                    int k = random.nextInt(500);
                    mine.deletePredecessor(k); ref.remove(k); what = "deletePredecessor(" + k + ")";
                }
                List<Integer> keys = new ArrayList<Integer>();
                for (int k : mine.keys()) keys.add(k);
                if (!keys.equals(new ArrayList<Integer>(ref.keySet())))
                    problem = "after operation " + t + ", " + what + ", the keys are wrong";
                else if (mine.size() != ref.size())
                    problem = "after operation " + t + ", " + what + ", size() is " + mine.size() + " but should be " + ref.size();
                else if (!mine.isSizeConsistent())
                    problem = "after operation " + t + ", " + what + ", some node's size count is wrong";
                else if (!ref.isEmpty()) {
                    int k = random.nextInt(500);
                    Integer a = mine.get(k), b = ref.get(k);
                    if (a == null ? b != null : !a.equals(b))
                        problem = "after operation " + t + ", " + what + ", get(" + k + ") returned " + a + " instead of " + b;
                }
            }
        } catch (RuntimeException e) {
            problem = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        } catch (StackOverflowError e) {
            problem = "StackOverflowError (a method that never stops calling itself?)";
        }
        System.out.printf("  Test %d: 20,000 random puts and deletes  %s%n", number, problem == null ? "PASS" : "FAIL");
        if (problem != null) System.out.println("    " + problem);
        return problem == null ? 1 : 0;
    }

    // Runs a test, turning a crash into a readable result instead of stopping.
    private static String attempt(Supplier<String> test) {
        try {
            return test.get();
        } catch (RuntimeException e) {
            return e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        } catch (StackOverflowError e) {
            return "StackOverflowError (a method that never stops calling itself?)";
        }
    }

    private static int report(int number, String what, String result, String expect) {
        boolean pass = result.equals(expect);
        System.out.printf("  Test %d: %s  %s%n", number, what, pass ? "PASS" : "FAIL");
        if (!pass) {
            System.out.println("    result: " + result);
            System.out.println("    expect: " + expect);
        }
        return pass ? 1 : 0;
    }
}
