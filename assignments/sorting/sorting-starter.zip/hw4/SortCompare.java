package hw4;

import java.util.Random;

// Doubling experiments for the sorts. (Already done. Don't change this file.)
//
// For each experiment, it sorts arrays of size n = 1,000, 2,000, 4,000, ...
// and prints how long each sort took and the doubling ratio (each time
// divided by the time on the line above it). An experiment stops once a
// single sort takes more than STOP_SECONDS, or n reaches MAX_N.
//
// Run it with all your sorts working. It can take a minute or two.
public class SortCompare {

    private static final double STOP_SECONDS = 1.0;
    private static final int MAX_N = 2_048_000;

    public static void main(String[] args) {
        warmUp();
        experiment("Insertion", false);
        experiment("Insertion", true);
        experiment("Merge", false);
        experiment("Merge", true);
        experiment("Quick", false);
    }

    // Runs one doubling experiment and prints its table.
    // If presorted is true, the input is already in ascending order.
    private static void experiment(String name, boolean presorted) {
        String input = presorted ? "already-sorted input" : "random input";
        System.out.println(name + ", " + input + ":");
        System.out.printf("  %10s %12s %8s%n", "n", "time (ms)", "ratio");

        double previous = 0;
        for (int n = 1_000; n <= MAX_N; n += n) {
            double seconds = bestOf(name, n, presorted);
            String ratio = previous > 0 ? String.format("%.1f", seconds / previous) : "";
            System.out.printf("  %,10d %12.1f %8s%n", n, seconds * 1000, ratio);
            previous = seconds;
            if (seconds > STOP_SECONDS) {
                break;
            }
        }
        System.out.println();
    }

    // Times one sort. If it was quick (under a quarter second), runs it
    // four more times and keeps the fastest, which smooths out noise
    // from whatever else your computer is doing.
    private static double bestOf(String name, int n, boolean presorted) {
        double best = timeTrial(name, n, presorted);
        if (best < 0.25) {
            for (int k = 0; k < 4; k++) {
                best = Math.min(best, timeTrial(name, n, presorted));
            }
        }
        return best;
    }

    // Returns the number of seconds it takes to sort one array of size n.
    private static double timeTrial(String name, int n, boolean presorted) {
        Random random = new Random(23);
        Double[] a = new Double[n];
        for (int i = 0; i < n; i++) {
            a[i] = presorted ? (double) i : random.nextDouble();
        }
        System.gc();   // clean up leftover arrays before timing
        long start = System.nanoTime();
        switch (name) {
            case "Insertion": Insertion.sort(a); break;
            case "Merge":     Merge.sort(a);     break;
            case "Quick":     Quick.sort(a);     break;
        }
        long end = System.nanoTime();
        if (!Selection.isSorted(a)) {
            throw new IllegalStateException(name + " didn't sort the array. Fix it before timing it.");
        }
        return (end - start) / 1e9;
    }

    // Runs each sort a few times first, so Java's just-in-time compiler
    // has optimized the code before we start timing.
    private static void warmUp() {
        for (int k = 0; k < 5; k++) {
            timeTrial("Insertion", 2_000, false);
            timeTrial("Merge", 20_000, false);
            timeTrial("Quick", 20_000, false);
        }
    }
}
