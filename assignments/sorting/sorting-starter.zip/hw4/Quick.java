package hw4;

import java.util.Arrays;
import java.util.Random;

public class Quick {

    // Rearranges the array into ascending order. (Already done.)
    public static void sort(Comparable[] a) {
        shuffle(a);   // eliminate dependence on input order
        sort(a, 0, a.length - 1);
    }

    // Sorts a[lo..hi].
    //
    // If the subarray has one item or fewer, it's already sorted.
    // Otherwise, partition it, then sort the part to the left of the
    // partitioning item and the part to the right of it.
    private static void sort(Comparable[] a, int lo, int hi) {
        // TODO
    }

    // Partitions a[lo..hi] around the partitioning item v = a[lo], and
    // returns j, the index where v ends up. Afterward:
    //   - every item in a[lo..j-1] is no greater than a[j]
    //   - every item in a[j+1..hi] is no less than a[j]
    //
    // 1. Set i = lo and j = hi + 1.
    // 2. Repeat:
    //      - Scan i to the right while a[i] < v (stop if i reaches hi).
    //      - Scan j to the left while v < a[j] (stop if j reaches lo).
    //      - If the pointers have crossed (i >= j), stop repeating.
    //      - Otherwise, exch(a, i, j).
    // 3. Put v into position: exch(a, lo, j). Return j.
    //
    // Hint: the book's version increments i and decrements j *before*
    // each comparison: less(a[++i], v) and less(v, a[--j]). That's why
    // i starts at lo and j starts at hi + 1.
    public static int partition(Comparable[] a, int lo, int hi) {
        return 0; // TODO
    }

    // Rearranges the array into a uniformly random order. (Already done.)
    private static void shuffle(Comparable[] a) {
        Random random = new Random();
        for (int i = 0; i < a.length; i++) {
            int r = i + random.nextInt(a.length - i);   // between i and n-1
            exch(a, i, r);
        }
    }

    // Is v < w? (Already done.)
    private static boolean less(Comparable v, Comparable w) {
        return v.compareTo(w) < 0;
    }

    // Exchanges a[i] and a[j]. (Already done.)
    private static void exch(Comparable[] a, int i, int j) {
        Comparable t = a[i];
        a[i] = a[j];
        a[j] = t;
    }

    // Returns true if the array is in ascending order. (Already done.)
    public static boolean isSorted(Comparable[] a) {
        for (int i = 1; i < a.length; i++) {
            if (less(a[i], a[i - 1])) {
                return false;
            }
        }
        return true;
    }

    // Prints the array on one line, for debugging. (Already done.)
    public static void show(Comparable[] a) {
        System.out.println(Arrays.toString(a));
    }
}
