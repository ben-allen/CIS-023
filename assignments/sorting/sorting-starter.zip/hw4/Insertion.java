package hw4;

import java.util.Arrays;

public class Insertion {

    // Rearranges the array into ascending order.
    //
    // For each i from 1 to n - 1, exchange a[i] with each larger item to
    // its left, moving it left until it's in place among a[0..i].
    // Use less() for every comparison and exch() for every move.
    public static void sort(Comparable[] a) {
        // TODO
    }

    // Is v < w? (Already done.)
    private static boolean less(Comparable v, Comparable w) {
        return v.compareTo(w) < 0;
    }

    // Exchanges a[i] and a[j]. (Already done.)
    private static void exch(Comparable[] a, int i, int j) {
        Comparable t = a[i];
        a[i] = a[j];
        a[j] = t;
    }

    // Returns true if the array is in ascending order. (Already done.)
    public static boolean isSorted(Comparable[] a) {
        for (int i = 1; i < a.length; i++) {
            if (less(a[i], a[i - 1])) {
                return false;
            }
        }
        return true;
    }

    // Prints the array on one line, for debugging. (Already done.)
    public static void show(Comparable[] a) {
        System.out.println(Arrays.toString(a));
    }
}
