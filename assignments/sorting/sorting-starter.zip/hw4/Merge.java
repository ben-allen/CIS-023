package hw4;

import java.util.Arrays;

public class Merge {

    // Rearranges the array into ascending order. (Already done.)
    public static void sort(Comparable[] a) {
        Comparable[] aux = new Comparable[a.length];   // allocate space just once
        sort(a, aux, 0, a.length - 1);
    }

    // STEP 2: Sorts a[lo..hi]. Write this AFTER merge passes MergeTest.
    //
    // If the subarray has one item or fewer (hi <= lo), it's already
    // sorted, so return. Otherwise:
    //   1. mid = lo + (hi - lo) / 2
    //   2. sort the left half, a[lo..mid]
    //   3. sort the right half, a[mid+1..hi]
    //   4. merge the two halves
    static void sort(Comparable[] a, Comparable[] aux, int lo, int hi) {
        // TODO
    }

    // STEP 1: Merges the sorted subarrays a[lo..mid] and a[mid+1..hi]
    // into one sorted subarray a[lo..hi]. Write this first, and test it
    // with MergeTest.
    //
    //   1. Copy a[lo..hi] into aux[lo..hi].
    //   2. Set i = lo (next unused item in the left half) and
    //      j = mid + 1 (next unused item in the right half).
    //   3. For each k from lo to hi, fill a[k] with ONE of these,
    //      checking in this order:
    //        - left half used up (i > mid):    take aux[j], then j++
    //        - right half used up (j > hi):    take aux[i], then i++
    //        - right item smaller (less(aux[j], aux[i])):
    //                                          take aux[j], then j++
    //        - otherwise:                      take aux[i], then i++
    static void merge(Comparable[] a, Comparable[] aux, int lo, int mid, int hi) {
        // TODO
    }

    // Is v < w? (Already done.)
    private static boolean less(Comparable v, Comparable w) {
        return v.compareTo(w) < 0;
    }

    // Returns true if the array is in ascending order. (Already done.)
    public static boolean isSorted(Comparable[] a) {
        for (int i = 1; i < a.length; i++) {
            if (less(a[i], a[i - 1])) {
                return false;
            }
        }
        return true;
    }

    // Prints the array on one line, for debugging. (Already done.)
    public static void show(Comparable[] a) {
        System.out.println(Arrays.toString(a));
    }
}
