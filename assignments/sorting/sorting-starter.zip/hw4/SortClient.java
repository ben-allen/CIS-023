package hw4;

import java.util.Arrays;
import java.util.Random;

// Tests your sorts. (Already done. Don't change this file.)
//
// For each sort, it sorts a small array of letters and prints the result,
// then sorts 10,000 random numbers and checks that the result is in order
// and still contains exactly the original items.
// It also checks Quick.partition on the partitioning example from the book.
//
// A sort you haven't written yet will show NOT SORTED. That's expected:
// for the checkpoint, Selection, Insertion, and Merge should all say OK.
public class SortClient {

    public static void main(String[] args) {
        String letters = "S O R T E X A M P L E";

        System.out.println("Sorting \"" + letters + "\":");
        for (String name : new String[] { "Selection", "Insertion", "Merge", "Quick" }) {
            String[] a = letters.split(" ");
            String[] original = a.clone();
            sort(name, a);
            System.out.printf("  %-10s %s  %s%n", name, Arrays.toString(a), verdict(original, a));
        }

        System.out.println();
        System.out.println("Sorting 10,000 random numbers:");
        for (String name : new String[] { "Selection", "Insertion", "Merge", "Quick" }) {
            Double[] a = randomArray(10_000, new Random(23));
            Double[] original = a.clone();
            sort(name, a);
            System.out.printf("  %-10s %s%n", name, verdict(original, a));
        }

        System.out.println();
        System.out.println("Partitioning \"K R A T E L E P U I M Q C X O S\":");
        String[] p = "K R A T E L E P U I M Q C X O S".split(" ");
        int j = Quick.partition(p, 0, p.length - 1);
        System.out.println("  result: " + Arrays.toString(p) + ", j = " + j);
        System.out.println("  expect: [E, C, A, I, E, K, L, P, U, T, M, Q, R, X, O, S], j = 5");
    }

    private static void sort(String name, Comparable[] a) {
        switch (name) {
            case "Selection": Selection.sort(a); break;
            case "Insertion": Insertion.sort(a); break;
            case "Merge":     Merge.sort(a);     break;
            case "Quick":     Quick.sort(a);     break;
        }
    }

    // OK only if the result is in order AND has exactly the same items as
    // the original (so a merge that copies an item twice won't pass).
    private static String verdict(Comparable[] original, Comparable[] result) {
        if (!Selection.isSorted(result)) {
            return "NOT SORTED";
        }
        Comparable[] expected = original.clone();
        Arrays.sort(expected);
        if (!Arrays.equals(expected, result)) {
            return "SORTED, BUT ITEMS WERE LOST OR DUPLICATED";
        }
        return "OK";
    }

    private static Double[] randomArray(int n, Random random) {
        Double[] a = new Double[n];
        for (int i = 0; i < n; i++) {
            a[i] = random.nextDouble();
        }
        return a;
    }
}
