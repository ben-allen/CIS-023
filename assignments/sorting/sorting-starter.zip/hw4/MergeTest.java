package hw4;

import java.util.Arrays;

// Tests your merge() by itself, before you write mergesort's recursive
// sort(). (Already done. Don't change this file.)
//
// Each test starts with an array whose two halves are already sorted,
// calls Merge.merge once, and checks the result.
public class MergeTest {

    private static int passed = 0;
    private static int total = 0;

    public static void main(String[] args) {
        test("interleaved halves",
             "A D L P B C M X", 0, 3, 7,
             "A B C D L M P X");

        test("left half runs out first",
             "A C E G B W X Y", 0, 3, 7,
             "A B C E G W X Y");

        test("right half runs out first",
             "W X Y Z A B C D", 0, 3, 7,
             "A B C D W X Y Z");

        test("halves of different sizes",
             "C F A B E G H", 0, 1, 6,
             "A B C E F G H");

        test("merging only the middle of the array (a[2..5])",
             "Z Z B K D H Z", 2, 3, 5,
             "Z Z B D H K Z");

        testTies();

        System.out.println();
        System.out.println(passed + " of " + total + " tests passed.");
        if (passed == total) {
            System.out.println("merge works. On to Step 2: the recursive sort().");
        }
    }

    private static void test(String name, String start, int lo, int mid, int hi, String expect) {
        total++;
        String[] a = start.split(" ");
        String[] expected = expect.split(" ");
        Comparable[] aux = new Comparable[a.length];
        System.out.println("Test " + total + ": " + name);
        System.out.println("  merge(a, aux, " + lo + ", " + mid + ", " + hi + ") on " + Arrays.toString(a));
        try {
            Merge.merge(a, aux, lo, mid, hi);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("  FAIL: index out of bounds (" + e.getMessage() + ").");
            System.out.println("        Check that you test for a used-up half BEFORE comparing.");
            return;
        }
        report(Arrays.toString(expected), Arrays.toString(a));
    }

    // Equal items must come out in the same order they went in: when the
    // left and right items are equal, take the LEFT one.
    private static void testTies() {
        total++;
        Tagged[] a = {
            new Tagged('A', 1), new Tagged('E', 1), new Tagged('M', 1),
            new Tagged('E', 2), new Tagged('Z', 2)
        };
        Comparable[] aux = new Comparable[a.length];
        System.out.println("Test " + total + ": ties go to the left half");
        System.out.println("  merge(a, aux, 0, 2, 4) on " + Arrays.toString(a));
        try {
            Merge.merge(a, aux, 0, 2, 4);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("  FAIL: index out of bounds (" + e.getMessage() + ").");
            return;
        }
        report("[A1, E1, E2, M1, Z2]", Arrays.toString(a));
    }

    private static void report(String expected, String result) {
        System.out.println("  expect: " + expected);
        System.out.println("  result: " + result);
        if (expected.equals(result)) {
            System.out.println("  PASS");
            passed++;
        } else {
            System.out.println("  FAIL");
        }
    }

    // A letter with a tag showing which half it started in. Compares by
    // letter only, so E1 and E2 count as equal.
    private static class Tagged implements Comparable<Tagged> {
        private final char letter;
        private final int tag;

        Tagged(char letter, int tag) {
            this.letter = letter;
            this.tag = tag;
        }

        public int compareTo(Tagged that) {
            return Character.compare(this.letter, that.letter);
        }

        public String toString() {
            return "" + letter + tag;
        }
    }
}
