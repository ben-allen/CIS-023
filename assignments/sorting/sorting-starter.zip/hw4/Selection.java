package hw4;

import java.util.Arrays;

// Selection sort, complete. (Already done.)
//
// You don't need to change anything in this file. It's here as a worked
// example of the pattern every sort in this assignment follows: all
// comparisons go through less(), and all moves go through exch().
public class Selection {

    // Rearranges the array into ascending order.
    public static void sort(Comparable[] a) {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            // Find the smallest remaining item and exchange it with a[i].
            int min = i;
            for (int j = i + 1; j < n; j++) {
                if (less(a[j], a[min])) {
                    min = j;
                }
            }
            exch(a, i, min);
        }
    }

    // Is v < w?
    private static boolean less(Comparable v, Comparable w) {
        return v.compareTo(w) < 0;
    }

    // Exchanges a[i] and a[j].
    private static void exch(Comparable[] a, int i, int j) {
        Comparable t = a[i];
        a[i] = a[j];
        a[j] = t;
    }

    // Returns true if the array is in ascending order.
    public static boolean isSorted(Comparable[] a) {
        for (int i = 1; i < a.length; i++) {
            if (less(a[i], a[i - 1])) {
                return false;
            }
        }
        return true;
    }

    // Prints the array on one line, for debugging.
    public static void show(Comparable[] a) {
        System.out.println(Arrays.toString(a));
    }
}
